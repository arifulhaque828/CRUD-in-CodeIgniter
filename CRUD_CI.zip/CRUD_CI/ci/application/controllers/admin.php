<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

  public function add_student()
  {
 $this->load->view('pages/add_student');
    
  }
  public function save_student(){
    
   $this->admin_model->save_student_info();
   $sdata=array();
    $sdata['message']='added done';
 $this->session->set_userdata($data);
    redirect('','refresh');
   }

 public function manage_student(){
    $data=array();
    $data['all_student_info']=$this->admin_model->all_student_info();
$data['admin_index']=$this->load->view('pages/manage_student','data',true);
   
     $this->load->view('pages/manage_student',$data);
  }
  public function edit_student($student_id){

 $data=array();
    $data['all_student_info_by_id']=$this->admin_model->all_student_info_by_id($student_id);
$data['admin_index']=$this->load->view('pages/edit_student','',true);
   
     $this->load->view('pages/edit_student',$data);

  }
  public function update_student(){

$this->admin_model->update_student_info();


redirect('','refresh');

  }  
    public function delete_student($student_id){
        $this->admin_model->delete_student_by_id($student_id);
 $sdata=array();
 $sdata['message']="delete success";
 $this->session->set_userdata($sdata);
 redirect('','refresh');
  }
}
