<html>
<head>

<link rel='stylesheet' type='text/css' href="front-end/style.css">
<link rel="stylesheet" type="text/css" href="front-end/bootstrap.min.css">
</head>
<body> 
<div class="container">
  <form action="<?php echo base_url();?>update-student" method="post">
      <div id="control-group">
    <label for="fname">Update Student Name</label>
    <input type="text" id="fname" 
    value="<?php echo $all_student_info_by_id->student_name;?>"
     name="student_name" placeholder="Your name.."></br>
  </div>
       <label for="fname"></label>
    <input type="hidden" id="fname" 
    value="<?php echo $all_student_info_by_id->student_id;?>" name="student_id" ></br>

    <label for="lname">Update Student Phone</label>
    <input type="text" 
     value="<?php echo $all_student_info_by_id->student_phone;?>"id="lname" required="" name="student_phone" ></br>
      <label for="lname">Update Student roll</label>
    <input type="text" id="lname"
     value="<?php echo $all_student_info_by_id->student_roll;?>"
      required="" name="student_roll" ></br>
  

    <input type="submit" value="Update">

  </form>
</div>

</body>
</html>





