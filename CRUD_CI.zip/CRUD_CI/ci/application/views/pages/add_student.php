<html>
<head>

<link rel='stylesheet' type='text/css' href="front-end/style.css">
<link rel="stylesheet" type="text/css" href="front-end/bootstrap.min.css">
</head>
<body>

  
<div class="container">

  <form action="<?php base_url();?>save-student" method="post">

    <label for="fname">Student Name</label>
    <input type="text" id="fname" required="" name="student_name">

    <label for="lname">Student Phone</label>
    <input type="text" id="lname" required="" name="student_phone">

   
      <label for="lname">Student roll</label>
    <input type="text" id="lname" required="" name="student_roll" >
  

    <input type="submit" value="Submit">

  </form>
</div>

</body>
</html>





