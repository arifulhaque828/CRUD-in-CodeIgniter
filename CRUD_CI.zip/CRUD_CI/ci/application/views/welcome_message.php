<!DOCTYPE html>
<html lang="en">

<head>
  <title>RTSOFTBD</title>
<link rel='stylesheet' type='text/css' href="front-end/style.css">
<link rel="stylesheet" type="text/css" href="front-end/bootstrap.min.css">

</head>

<body>

  <div class="rtsoftbd">

        <a  class="nav-link collapsed" href="<?php echo base_url()?>add-student ">
          
          <span><h1>Add-student</h1></span>
        </a>
     

    <a  class="nav-link collapsed" href="<?php base_url()?>manage-student">
        
          <span><h1>Manage-student</h1></span>
        </a>
        
    </div>


</body>

</html>
